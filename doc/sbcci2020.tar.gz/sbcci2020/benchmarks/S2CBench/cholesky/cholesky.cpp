//========================================================================================
//
// File Name    : cholesky.cpp
// Description  : cholesky decomposition implementaiton function
// Release Date : 12/04/2017
// Author       : UTD DARClab
//                Benjamin Carrion Schafer
//
// Revision History
//---------------------------------------------------------------------------------------
// Date         Version    Author      Description
//---------------------------------------------------------------------------------------
//12/04/2017      1.0      UTD (BCS)   Cholesky decomposition main description
//=======================================================================================

#include "cholesky.h"

#define MAX 255

const sc_fixed<16,8,SC_RND,SC_SAT> sqrt_lut[128] = {
		0.00,
		1.00,
		1.41,
		1.73,
		2.00,
		2.24,
		2.45,
		2.65,
		2.83,
		3.00,
		3.16,
		3.32,
		3.46,
		3.61,
		3.74,
		3.87,
		4.00,
		4.12,
		4.24,
		4.36,
		4.47,
		4.58,
		4.69,
		4.80,
		4.90,
		5.00,
		5.10,
		5.20,
		5.29,
		5.39,
		5.48,
		5.57,
		5.66,
		5.74,
		5.83,
		5.92,
		6.00,
		6.08,
		6.16,
		6.24,
		6.32,
		6.40,
		6.48,
		6.56,
		6.63,
		6.71,
		6.78,
		6.86,
		6.93,
		7.00,
		7.07,
		7.14,
		7.21,
		7.28,
		7.35,
		7.42,
		7.48,
		7.55,
		7.62,
		7.68,
		7.75,
		7.81,
		7.87,
		7.94,
		8.00,
		8.06,
		8.12,
		8.19,
		8.25,
		8.31,
		8.37,
		8.43,
		8.49,
		8.54,
		8.60,
		8.66,
		8.72,
		8.77,
		8.83,
		8.89,
		8.94,
		9.00,
		9.06,
		9.11,
		9.17,
		9.22,
		9.27,
		9.33,
		9.38,
		9.43,
		9.49,
		9.54,
		9.59,
		9.64,
		9.70,
		9.75,
		9.80,
		9.85,
		9.90,
		9.95,
		10.00,
		10.05,
		10.10,
		10.15,
		10.20,
		10.25,
		10.30,
		10.34,
		10.39,
		10.44,
		10.49,
		10.54,
		10.58,
		10.63,
		10.68,
		10.72,
		10.77,
		10.82,
		10.86,
		10.91,
		10.95,
		11.00,
		11.05,
		11.09,
		11.14,
		11.18,
		11.22,
		11.27
};

/* C */
void cholesky::cholesky_main() {
	// Variables declaration
	sc_fixed<16,8,SC_RND,SC_SAT> in_data_read[MATRIX_SIZE];
	int i;

	// Reset state - should be executable in 1 clock cycle
	wait();

	// Main thread
	while (1) {
		for(i=0;i<MATRIX_SIZE;i++){
			in_data_read[i] = in_data[i].read();
		}

		// Cholesky main computation  function
		cholesky_compute(in_data_read);

		for(i=0;i<MATRIX_SIZE;i++){
			cholesky_output[i].write(L[i]);
		}

		wait();
	}
}

void cholesky::cholesky_compute(sc_fixed<16,8,SC_RND,SC_SAT>  m1[MATRIX_SIZE]) {
	unsigned int  i,j, k, n=MATRIX_DIM, index_sqrt=0;
	sc_fixed<16,8,SC_TRN,SC_SAT> s=0;
	sc_fixed<16,8,SC_TRN,SC_SAT> c=1;

	for (i = 0; i < n; i++) {
		for (j = 0; j < (i+1); j++) {
			s = 0;
			for (k = 0; k < j; k++)
				s += L[i * n + k] * L[j * n + k];

			if(i == j){
				index_sqrt = m1[i * n + i] - s;
				L[(i * n) + j] = sqrt_lut[index_sqrt];
			} else {
				if( L[j * n + j] != 0)
					L[i * n + j] = (c / L[(j * n) + j] * (m1[(i * n) + j] - s));
				else
					L[i * n + j] = 0;

			}
		}
	}
}
