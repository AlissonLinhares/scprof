//========================================================================================
// 
// File Name    : jpeg_encoder.cpp
// Description  : JPEG encoder top module
// Release Date : 30/05/2017
// Author       : UT Dallas DARClab
//                Jianqi Chen, Benjamin Carrion Schafer
// 
//
// Revision History
//---------------------------------------------------------------------------------------
// Date         Version         Author          Description
//----------------------------------------------------------------------------------------
// 30/05/2017        1.0        UTD DARClab     JPEG encoder
//=======================================================================================

#include "jpeg_encoder.h"
